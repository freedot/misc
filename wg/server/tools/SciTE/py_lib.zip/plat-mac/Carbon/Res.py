try:
    from OverrideFrom23._Res import *
except ImportError:
    from _Res import *
