"""curses.panel

Module for using panels with curses.
"""

__revision__ = "$Id: panel.py 18511 2000-12-22 21:58:29Z akuchling $"

from _curses_panel import *

